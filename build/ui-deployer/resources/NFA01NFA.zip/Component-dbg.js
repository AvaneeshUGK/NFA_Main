sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("NFA01.NFA.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);