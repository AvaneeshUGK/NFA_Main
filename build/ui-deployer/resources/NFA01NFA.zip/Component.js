sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("NFA01.NFA.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map