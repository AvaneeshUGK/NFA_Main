sap.ui.define(["sap/m/MessageToast"],function(n){"use strict";return{uploadfun:function(s){n.show("Custom handler invoked.")}}});
//# sourceMappingURL=Uploadpdf.js.map